SavefileManager.PROGRESS_SLOT = 69
SavefileManager.BACKUP_SLOT = 69
